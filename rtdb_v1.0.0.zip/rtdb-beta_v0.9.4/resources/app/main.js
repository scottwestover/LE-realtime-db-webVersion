/*********************
 * Module dependencies
 *********************/
'use strict';
const electron = require('electron');
// Module to control application life.
const app = electron.app;
// Module to create native browser window.
const BrowserWindow = electron.BrowserWindow;

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow;

var express = require('express');
var request = require('request');
var routes = require('./routes');
var expressApp = express();
expressApp.engine('html', require('ejs').renderFile);

/***************
 * Configuration
 ***************/
expressApp.set('port', (process.env.PORT || 5000));
expressApp.use(express.static(__dirname + '/public'));

// views is directory for all template files
expressApp.set('views', __dirname + '/views');
expressApp.set('view engine', 'html');

/********
 * Routes
 ********/
// serve index and view partials
expressApp.get('/', routes.startupPage);
expressApp.get('/partials/:name', routes.partials);
expressApp.get('/agentActivity', routes.agentActivity);
expressApp.get('/saveSettings', routes.saveSettings);
expressApp.post('/getOauth', routes.getOauth);
expressApp.get('/queueHealth', routes.queueHealth);
expressApp.get('/queueHealth2', routes.queueHealth2);
expressApp.get('/engagementActivity', routes.engagementActivity);
expressApp.get('/engagementActivity2', routes.engagementActivity2);
expressApp.get('/currentQueueState', routes.currentQueueState);
expressApp.get('/skillList', routes.skillList);
expressApp.get('/agentList', routes.agentList);
expressApp.get('/agentGroupList', routes.agentGroupList);
expressApp.get('/startup', routes.startup);
expressApp.get('/startupStatus', routes.startupStatus);
expressApp.get('/startupPage', routes.startupPage);
expressApp.get('/mainPage', routes.index);
expressApp.get('/error', routes.error);
expressApp.get('/sla', routes.sla);
// serve messaging views
expressApp.get('/messagingConversation', routes.messagingConversation);
expressApp.get('/messagingCSAT', routes.messagingCSAT);
expressApp.get('/saveSettingsMsg', routes.saveSettingsMsg);
expressApp.post('/getOauthMsg', routes.getOauthMsg);
// redirect all others to the index (HTML5 history)
expressApp.get('*', routes.index);

/**************
 * Start Server
 **************/
expressApp.listen(expressApp.get('port'), function () {
    console.log('Node app is running on port', expressApp.get('port'));
});

function createWindow() {
    // Create the browser window.
    mainWindow = new BrowserWindow({
        autoHideMenuBar: true,
        width: 800,
        height: 600
    });
    mainWindow.maximize();
    // and load the index.html of the app.
    mainWindow.loadURL('http://localhost:5000/');

    // Open the DevTools.
    //mainWindow.webContents.openDevTools();

    // Emitted when the window is closed.
    mainWindow.on('closed', function () {
        // Dereference the window object, usually you would store windows
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        mainWindow = null;
    });
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
app.on('ready', function () {
    createWindow();
});

// Quit when all windows are closed.
app.on('window-all-closed', function () {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', function () {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
        createWindow();
    }
});
